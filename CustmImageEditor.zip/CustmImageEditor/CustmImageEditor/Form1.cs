﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CustmImageEditor
{
    public partial class Form1 : Form
    {
        public static Pen selectedPen { get; set; }
        public static int RectSize { get; set; }
        public int PenSize { get; set; }
        public static Graphics graphics { get; set; }
        public static string rectValue { get; set; }
        public static string filePath { get; set; }
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //Note: pbImage is the name of the picture box used here.
            var mouseEventArgs = e as MouseEventArgs;
            int x = mouseEventArgs.Location.X;
            int y = mouseEventArgs.Location.Y;

            // We first cast the "Image" property of the pbImage picture box control
            // into a Bitmap object.
            Bitmap pbImageBitmap = (Bitmap)(pictureBox1.Image);
            // Obtain a Graphics object from the Bitmap object.
            graphics = Graphics.FromImage((Image)pbImageBitmap);

           Pen whitePen = new Pen(Color.White, 1);
            // Show the coordinates of the mouse click on the label, label1.
            label1.Text = "X: " + x + " Y: " + y;
            Rectangle rect = new Rectangle(x, y, RectSize, RectSize);

            // Draw the rectangle, starting with the given coordinates, on the picture box.
            selectedPen.Width = PenSize;
            graphics.DrawRectangle(selectedPen, rect);
            System.Drawing.SolidBrush myBrush = new System.Drawing.SolidBrush(selectedPen.Color);
            Font font = new Font("Times New Roman", 12.0f);
            graphics.DrawString(rectText.Text, font, myBrush,x,y);
            
            // Refresh the picture box control in order that
            // our graphics operation can be rendered.
            pictureBox1.Refresh();

            // Calling Dispose() is like calling the destructor of the respective object.
            // Dispose() clears all resources associated with the object, but the object still remains in memory
            // until the system garbage-collects it.
            graphics.Dispose();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            // Pen whitePen = new Pen(Color.White);
            PenSize = 1;
            selectedPen = new Pen(Color.White, 1);
            RectSize = 20;
            RectColor whitePen = new RectColor() { p = new Pen(Color.White), ColorName = "White" };
            RectColor redPen = new RectColor() { p = new Pen(Color.Red), ColorName = "Red" };
            RectColor blackPen = new RectColor() { p = new Pen(Color.Black), ColorName = "Black" };
            RectColor yellowPen = new RectColor() { p = new Pen(Color.Yellow), ColorName = "Yellow" };
            comboBoxColor.DisplayMember = "ColorName";
            comboBoxColor.ValueMember = "p";
            comboBoxColor.SelectedValue = whitePen ;
            comboBoxColor.Items.Add(redPen);
            comboBoxColor.Items.Add(blackPen);
            comboBoxColor.Items.Add(yellowPen);
            comboBoxRectSize.ValueMember = "size";
            comboBoxRectSize.DisplayMember = "size";
            comboBoxRectSize.Items.Add(new RectSize() { size= 20});
            comboBoxRectSize.Items.Add(new RectSize() { size = 40 });
            comboBoxRectSize.Items.Add(new RectSize() { size = 50 });
            comboBoxRectSize.Items.Add(new RectSize() { size = 60 });
            comboBoxRectSize.Items.Add(new RectSize() { size = 80});
            
            comboBoxPenSize.ValueMember = "size";
            comboBoxRectSize.DisplayMember = "size";
            comboBoxPenSize.Items.Add(new PenSize() { size = 1 });
            comboBoxPenSize.Items.Add(new PenSize() { size = 2});
            comboBoxPenSize.Items.Add(new PenSize() { size = 3 });
            comboBoxPenSize.Items.Add(new PenSize() { size = 4 });
            comboBoxPenSize.Items.Add(new PenSize() { size = 5});
            comboBoxPenSize.Items.Add(new PenSize() { size = 6});
            comboBoxColor.SelectedIndex = 0;
            comboBoxRectSize.SelectedIndex = 0;
            comboBoxPenSize.SelectedIndex = 0;
            RectSize = 20;
        }

        private void comboBoxColor_SelectedIndexChanged(object sender, EventArgs e)
        {
            //selectedPen = (Pen)comboBoxColor.SelectedValue;
            selectedPen = ((RectColor)comboBoxColor.SelectedItem).p;
            //selectedPen.Width = PenSize;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            graphics.Clear(Color.Yellow);
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Bitmap bm = new Bitmap(pictureBox1.Image);
            bm.Save(fileSavePath.Text+"\\"+ saveImageName.Text+".bmp", System.Drawing.Imaging.ImageFormat.Bmp);
           // pictureBox1.Image.Save(@"D:\DayUsers\Sunil Pandey\Practice\Angular\R&D\ImageEditorImages", ImageFormat.Jpeg);
        }

        private void  SelectImage() {
             filePath = "";
            // Create and open a file selector
            OpenFileDialog opnDlg = new OpenFileDialog();
            opnDlg.InitialDirectory = ".";

            // select filter type
           // opnDlg.Filter = "Parm Files (*.parm)|*.parmAll Files (*.*)|*.*";

            if (opnDlg.ShowDialog(this) == DialogResult.OK)
            {
                // If file is in start folder remove path
                FileInfo f = new FileInfo(opnDlg.FileName);

                // use relative path if under application
                // starting directory
                fileSavePath.Text = f.DirectoryName;
                if (f.DirectoryName == Application.StartupPath)
                    filePath = f.Name;  // only file name
                else if (f.DirectoryName.StartsWith(Application.StartupPath))
                    // relative path
                    filePath = f.FullName.Replace(Application.StartupPath, ".");
                else
                    filePath = f.FullName;  // Full path
            }
            Image image = Image.FromFile(filePath);
            this.pictureBox1.Image = image;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SelectImage();
        }

        private void comboBoxPenSize_SelectedIndexChanged(object sender, EventArgs e)
        {
            PenSize = ((PenSize)comboBoxPenSize.SelectedItem).size;

        }

        private void comboBoxRectSize_SelectedIndexChanged(object sender, EventArgs e)
        {
            //RectSize = Convert.ToInt32(comboBoxRectSize.SelectedValue);
            RectSize = ((RectSize)comboBoxRectSize.SelectedItem).size;
        }
    }

    public class RectColor{
        public Pen p { get; set; }
        public string ColorName { get; set; }

    }
    public class RectSize
    {
        public int size { get; set; }
      

    }
    public class PenSize
    {
        public int size { get; set; }


    }
}
